 // Fetch the JSON file
fetch('../assets/data/yonsei_data.json')
.then(response => response.json())
.then(data => {
    // Get the container element
    const container = document.getElementById('essay_yonsei');

    // Create HTML content from the JSON data
    const htmlContent = `
        <h2>${data.year}</h2>
        <p class="fs-6 mb-4"><strong>Document (가):</strong> <br> ${data.document_a}</p>
        <p class="fs-6 mb-4"><strong>Document (나):</strong> <br> ${data.document_b}</p>
        <p class="fs-6 mb-4"><strong>Document (다):</strong> <br> ${data.document_c}</p>
        <p class="fs-6 mb-4"><strong>Document (라):</strong> <br> ${data.document_d}</p>
        <img src="../assets/img/essay_writing/example.png" width=900 alt="">
        <p class="fs-6 mb-4"><strong>Question 1-1:</strong> <br> ${data.question_1_1}</p>
        <textarea name="" id="" cols="100" rows="8"></textarea>
        <p class="fs-6 mb-4"><strong>Question 1-2:</strong> <br> ${data.question_1_2}</p>
        <p class="fs-6 mb-4"><strong>지문 A:</strong> ${data.text_a}</p>
        <textarea name="" id="" cols="100" rows="8"></textarea>
        <p class="fs-6 mb-4"><strong>Question 2-1:</strong> <br> ${data.question_2_1}</p>
        <textarea name="" id="" cols="100" rows="8"></textarea>
        <p class="fs-6 mb-4"><strong>Question 2-2:</strong> <br> ${data.question_2_2}</p>
        <textarea name="" id="" cols="100" rows="8"></textarea>
        <button id="submit-tn" class="btn btn-primary" height="100" width="200">제출</button>
        <br>
        <div id="response-area"></div>
    `;

    // Set the HTML content
    container.innerHTML = htmlContent;

    document.getElementById('submit-tn').addEventListener("click", async () => { 
        const textareaValues = Array.from(document.querySelectorAll('textarea')).map(textarea => textarea.value);

        const messages = [
            {role: "system", content: `당신은 대학 입학 논술시험 전문 출제 위원이자 채점자입니다. 학생의 답안을 주어진 지문에 근거하여 논리적으로 평가하고, 첨삭을 수행하십시오. 제시문'과 '문제', '예시 답안지'에 기반해서 '학생의 답안지'를 아래 강령에 따라 첨삭하고, 답안을 보완하기 위한 조언을 해야합니다. 

            첨삭 내용은 다음 세 단계에 걸쳐 수행됩니다.
            [step1] 상 / 중 / 하 (전체적인 내용을 요약해 한 문장으로 제시하십시오. 상, 중, 하의 평가와 함께 이유를 간단히 설명하십시오.)
            [step2] 문장별 첨삭(학생의 답안을 한 문장씩 평가하고, 첨삭이 필요한 부분은 **논리적으로** 첨삭하십시오. 문법, 어휘, 논리적 흐름을 고려하십시오.)
            [step3] 총평(논리력, 지문독해력, 필력 등의 내용을 종합적으로 평가하고, 이후 공부 방향 또는 답안 작성 방향을 제시하십시오.)
            [step4] 답안지에 제시문 내용과 관계없는 학생의 주관이 반영된 내용이 있다고 판단되면, 해당 문장에 취소선을 그어 출력하고 주관을 반영해서는 안 된다는 조언을 하세요.
            
            언급한 세 단계 이외의 내용은 유저에게 제공해서는 안 되며, 답변은 반드시 한글로 작성되어야 합니다.`},
            {role: "assistant", content: `${data.document_a}`},
            {role: "assistant", content: `${data.document_b}`},
            {role: "assistant", content: `${data.document_c}`},
            {role: "assistant", content: `${data.document_d}`},
            {role: "assistant", content: `${data.table}`},
            {role: "assistant", content: `${data.figure}`},
            {role: "assistant", content: `${data.question_1_1}`},
            {role: "user", content: `${textareaValues[0]}`},
            {role: "assistant", content: `${data.question_1_2}`},
            {role: "assistant", content: `${data.text_a}`},
            {role: "user", content: `${textareaValues[1]}`},
            {role: "assistant", content: `${data.question_2_1}`},
            {role: "user", content: `${textareaValues[2]}`},
            {role: "assistant", content: `${data.question_2_2}`},
            {role: "user", content: `${textareaValues[3]}`},
        ];
        try {
            fetch('/api/gpt-essay-review', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ messages })
            })
            .then((res) => res.text())
            .then((text) => {
                document.getElementById('response-area').innerHTML = `<h3>Review Result:</h3><p>${text}</p>`;
            })
            .catch((err) => {
                document.getElementById('response-area').innerHTML = `<h3>Review Result:</h3><p>Error1: ${error.message}</p>`;
            });
        } catch (error) {
            document.getElementById('response-area').innerHTML = `<h3>Review Result:</h3><p>Error2: ${error.message}</p>`;
        }
    });
})
.catch(error => {
    console.error('Error loading the JSON file:', error);
    document.getElementById('content').innerHTML = '<p>Error loading data.</p>';
});